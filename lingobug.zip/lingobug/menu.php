<?php
// Menu lateral - incluído nas páginas internas
include_once 'db.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}
?>
<div class="menu">
    <div class="logo">Ling🐞Bug</div>
    <ul>
        <li><a href="sobre.php">Sobre</a></li>
        <li><a href="regras.php">Regras</a></li>
        <li><a href="dicas.php">Dicas</a></li>
        <li><a href="teste.php">Fazer Teste</a></li>
        <li><a href="perfil.php">Meu Perfil</a></li>
        <li><a href="politica.php">Política</a></li>
        <li><a href="logout.php">Sair</a></li>
    </ul>
</div>
