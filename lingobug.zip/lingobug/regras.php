<?php include 'menu.php'; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>LingoBug - Regras</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="conteudo">
        <h1>Regras do Teste</h1>
        <p>1. O teste possui <strong>10 questões</strong> de inglês.</p>
        <p>2. Cada questão tem um peso diferente (1, 2 ou 3 pontos).</p>
        <p>3. Você deve marcar apenas <strong>uma</strong> alternativa por questão.</p>
        <p>4. Não é possível voltar para alterar respostas após enviar.</p>
        <p>5. No final, você verá sua pontuação e o seu nível: Iniciante, Intermediário ou Avançado.</p>
        <p>Boa sorte! 🐞</p>
    </div>
</body>
</html>
