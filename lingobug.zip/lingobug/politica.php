<?php include 'menu.php'; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>LingoBug - Política de Privacidade</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="conteudo">
        <h1>Política de Privacidade</h1>
        <p>O LingoBug coleta apenas os dados necessários para o funcionamento da plataforma: nome, e-mail e data de nascimento.</p>
        <p>Suas informações <strong>não são compartilhadas</strong> com terceiros.</p>
        <p>Sua senha é armazenada de forma criptografada.</p>
        <p>Você pode editar ou excluir seus dados a qualquer momento na página do seu perfil.</p>
    </div>
</body>
</html>
