<?php
include 'db.php';

$mensagem = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    $sql = "SELECT id FROM usuarios WHERE email = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Guarda o e-mail na sessão para usar na próxima tela
        $_SESSION['email_recuperar'] = $email;
        header("Location: nova-senha.php");
        exit;
    } else {
        $mensagem = "E-mail não encontrado.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>LingoBug - Recuperar Senha</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="logo">Ling🐞Bug</div>

        <div class="card">
            <h1>RECUPERAR</h1>
            <form method="POST" action="recuperar.php">
                <label>Digite seu e-mail</label>
                <input type="email" name="email" required>

                <?php if ($mensagem != "") { echo "<div class='erro'>$mensagem</div>"; } ?>

                <div class="acoes">
                    <a href="index.php">Voltar</a>
                    <button type="submit" class="botao">Continuar</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
