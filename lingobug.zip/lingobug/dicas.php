<?php include 'menu.php'; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>LingoBug - Dicas</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="conteudo">
        <h1>Dicas de Estudo</h1>
        <p>📖 Leia textos curtos em inglês todos os dias.</p>
        <p>🎵 Ouça músicas e tente entender a letra.</p>
        <p>🎬 Assista filmes e séries com legendas em inglês.</p>
        <p>✏️ Anote palavras novas em um caderno.</p>
        <p>🗣️ Pratique a fala em voz alta, mesmo sozinho.</p>
        <p>💡 Estude um pouco todos os dias, ao invés de muito de uma vez só.</p>
    </div>
</body>
</html>
