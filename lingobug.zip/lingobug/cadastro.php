<?php
include 'db.php';

$erro = "";
$sucesso = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $senha = $_POST['senha'];
    $confirma = $_POST['confirma'];
    $nascimento = $_POST['nascimento'];

    if ($senha != $confirma) {
        $erro = "As senhas não conferem.";
    } elseif (strlen($senha) < 6) {
        $erro = "A senha deve ter no mínimo 6 caracteres.";
    } else {
        // Verifica se o e-mail já existe
        $sql = "SELECT id FROM usuarios WHERE email = ?";
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $erro = "E-mail já cadastrado.";
        } else {
            $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
            $sql = "INSERT INTO usuarios (nome, email, senha, data_nascimento) VALUES (?, ?, ?, ?)";
            $stmt = $conexao->prepare($sql);
            $stmt->bind_param("ssss", $nome, $email, $senha_hash, $nascimento);

            if ($stmt->execute()) {
                $sucesso = "Cadastro realizado! Você já pode entrar.";
            } else {
                $erro = "Erro ao cadastrar. Tente novamente.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>LingoBug - Cadastro</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="logo">Ling🐞Bug</div>

        <div class="card">
            <h1>CADASTRO</h1>
            <form method="POST" action="cadastro.php">
                <label>Nome</label>
                <input type="text" name="nome" required>

                <label>E-mail</label>
                <input type="email" name="email" required>

                <label>Data de Nascimento</label>
                <input type="date" name="nascimento">

                <label>Senha</label>
                <input type="password" name="senha" required>

                <label>Confirmar Senha</label>
                <input type="password" name="confirma" required>

                <?php if ($erro != "") { echo "<div class='erro'>$erro</div>"; } ?>
                <?php if ($sucesso != "") { echo "<div class='sucesso'>$sucesso</div>"; } ?>

                <div class="acoes">
                    <a href="index.php">Voltar</a>
                    <button type="submit" class="botao">Cadastrar</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
