<?php
// Conexão com o banco de dados MySQL
// Altere os dados abaixo conforme o seu servidor (XAMPP/WAMP)

$servidor = "localhost";
$usuario  = "root";
$senha    = "";
$banco    = "lingobug";

$conexao = new mysqli($servidor, $usuario, $senha, $banco);

if ($conexao->connect_error) {
    die("Erro de conexão: " . $conexao->connect_error);
}

$conexao->set_charset("utf8mb4");

// Inicia a sessão (usada para login)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
