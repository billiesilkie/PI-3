<?php
include 'db.php';

if (!isset($_SESSION['email_recuperar'])) {
    header("Location: recuperar.php");
    exit;
}

$erro = "";
$sucesso = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nova = $_POST['nova'];
    $confirma = $_POST['confirma'];

    if ($nova != $confirma) {
        $erro = "As senhas não conferem.";
    } elseif (strlen($nova) < 6) {
        $erro = "A senha deve ter no mínimo 6 caracteres.";
    } else {
        $email = $_SESSION['email_recuperar'];
        $senha_hash = password_hash($nova, PASSWORD_DEFAULT);

        $sql = "UPDATE usuarios SET senha = ? WHERE email = ?";
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ss", $senha_hash, $email);

        if ($stmt->execute()) {
            $sucesso = "Senha alterada! Faça login novamente.";
            unset($_SESSION['email_recuperar']);
        } else {
            $erro = "Erro ao alterar a senha.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>LingoBug - Nova Senha</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="logo">Ling🐞Bug</div>

        <div class="card">
            <h1>NOVA SENHA</h1>
            <form method="POST" action="nova-senha.php">
                <label>Nova senha</label>
                <input type="password" name="nova" required>

                <label>Confirmar nova senha</label>
                <input type="password" name="confirma" required>

                <?php if ($erro != "") { echo "<div class='erro'>$erro</div>"; } ?>
                <?php if ($sucesso != "") { echo "<div class='sucesso'>$sucesso</div>"; } ?>

                <div class="acoes">
                    <a href="index.php">Ir para login</a>
                    <button type="submit" class="botao">Salvar</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
