<?php
// Tela de login - página inicial
include 'db.php';

$erro = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $sql = "SELECT * FROM usuarios WHERE email = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows == 1) {
        $usuario = $resultado->fetch_assoc();
        if (password_verify($senha, $usuario['senha'])) {
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['nome'] = $usuario['nome'];
            header("Location: sobre.php");
            exit;
        } else {
            $erro = "Senha incorreta.";
        }
    } else {
        $erro = "E-mail não cadastrado.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>LingoBug - Entrar</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="logo">Ling🐞Bug</div>

        <div class="card">
            <h1>ENTRAR</h1>
            <form method="POST" action="index.php">
                <label for="email">E-mail</label>
                <input type="email" name="email" id="email" required>

                <label for="senha">Senha</label>
                <input type="password" name="senha" id="senha" required>

                <?php if ($erro != "") { echo "<div class='erro'>$erro</div>"; } ?>

                <div class="acoes">
                    <a href="recuperar.php">Esqueci a senha</a>
                    <div>
                        <a href="cadastro.php" class="botao-claro">Cadastrar</a>
                        <button type="submit" class="botao">Entrar</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
