<?php include 'menu.php'; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>LingoBug - Sobre</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="conteudo">
        <h1>Sobre o LingoBug</h1>
        <p>O <strong>LingoBug</strong> é uma plataforma simples para você descobrir e melhorar o seu nível de inglês.</p>
        <p>Através de um teste rápido, você descobre se está no nível Iniciante, Intermediário ou Avançado e recebe dicas para evoluir.</p>
        <p>Olá, <strong><?php echo htmlspecialchars($_SESSION['nome']); ?></strong>! Bem-vindo(a) ao LingoBug 🐞</p>
    </div>
</body>
</html>
