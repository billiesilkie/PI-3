-- Banco de dados do LingoBug
-- Execute este arquivo no phpMyAdmin ou MySQL

CREATE DATABASE IF NOT EXISTS lingobug CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lingobug;

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    data_nascimento DATE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de questões do teste
CREATE TABLE IF NOT EXISTS questoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pergunta TEXT NOT NULL,
    alternativa_a VARCHAR(255) NOT NULL,
    alternativa_b VARCHAR(255) NOT NULL,
    alternativa_c VARCHAR(255) NOT NULL,
    alternativa_d VARCHAR(255) NOT NULL,
    correta CHAR(1) NOT NULL,
    peso INT DEFAULT 1
);

-- Tabela de resultados dos testes
CREATE TABLE IF NOT EXISTS resultados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    pontuacao INT NOT NULL,
    nivel VARCHAR(20) NOT NULL,
    data_teste TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Questões de exemplo
INSERT INTO questoes (pergunta, alternativa_a, alternativa_b, alternativa_c, alternativa_d, correta, peso) VALUES
('What ___ your name?', 'is', 'are', 'am', 'be', 'a', 1),
('She ___ to school every day.', 'go', 'goes', 'going', 'gone', 'b', 1),
('They ___ playing football now.', 'is', 'am', 'are', 'be', 'c', 1),
('I ___ coffee yesterday.', 'drink', 'drank', 'drunk', 'drinking', 'b', 2),
('If I ___ rich, I would travel.', 'am', 'was', 'were', 'be', 'c', 3),
('He has ___ in London for 5 years.', 'live', 'lived', 'living', 'lives', 'b', 2),
('The book ___ written by her.', 'was', 'is', 'were', 'are', 'a', 2),
('I wish I ___ speak French.', 'can', 'could', 'will', 'would', 'b', 3),
('By next year, she ___ graduated.', 'will have', 'will', 'has', 'had', 'a', 3),
('He suggested ___ a movie.', 'to watch', 'watch', 'watching', 'watched', 'c', 3);
