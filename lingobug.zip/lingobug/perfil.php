<?php
include 'menu.php';

$id = $_SESSION['usuario_id'];
$mensagem = "";

// Atualiza dados
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['atualizar'])) {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $nascimento = $_POST['nascimento'];

    $sql = "UPDATE usuarios SET nome = ?, email = ?, data_nascimento = ? WHERE id = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("sssi", $nome, $email, $nascimento, $id);

    if ($stmt->execute()) {
        $_SESSION['nome'] = $nome;
        $mensagem = "Dados atualizados com sucesso!";
    }
}

// Excluir conta
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['excluir'])) {
    $sql = "DELETE FROM usuarios WHERE id = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    session_destroy();
    header("Location: index.php");
    exit;
}

// Busca dados do usuário
$sql = "SELECT * FROM usuarios WHERE id = ?";
$stmt = $conexao->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$usuario = $stmt->get_result()->fetch_assoc();

// Busca histórico de resultados
$sql = "SELECT * FROM resultados WHERE usuario_id = ? ORDER BY data_teste DESC";
$stmt = $conexao->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$resultados = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>LingoBug - Meu Perfil</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="conteudo">
        <h1>Meu Perfil</h1>

        <?php if ($mensagem != "") { echo "<div class='sucesso'>$mensagem</div>"; } ?>

        <form method="POST" action="perfil.php">
            <label>Nome</label>
            <input type="text" name="nome" value="<?php echo htmlspecialchars($usuario['nome']); ?>" required style="border: 1px solid #ccc; color: #333; padding: 8px;">

            <label>E-mail</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($usuario['email']); ?>" required style="border: 1px solid #ccc; color: #333; padding: 8px;">

            <label>Data de Nascimento</label>
            <input type="date" name="nascimento" value="<?php echo $usuario['data_nascimento']; ?>" style="border: 1px solid #ccc; color: #333; padding: 8px;">

            <div class="acoes">
                <button type="submit" name="atualizar" class="botao">Salvar</button>
                <button type="submit" name="excluir" class="botao-claro" onclick="return confirm('Tem certeza que deseja excluir sua conta?');">Excluir Conta</button>
            </div>
        </form>

        <h2 style="color:#1a2a6c; margin-top:30px;">Histórico de Testes</h2>
        <?php if ($resultados->num_rows == 0) { ?>
            <p>Você ainda não realizou nenhum teste.</p>
        <?php } else { ?>
            <table style="width:100%; border-collapse: collapse; margin-top:10px;">
                <tr style="background:#a8b8f0; color:white;">
                    <th style="padding:8px;">Data</th>
                    <th style="padding:8px;">Pontuação</th>
                    <th style="padding:8px;">Nível</th>
                </tr>
                <?php while ($r = $resultados->fetch_assoc()) { ?>
                    <tr style="border-bottom:1px solid #ddd;">
                        <td style="padding:8px;"><?php echo date('d/m/Y H:i', strtotime($r['data_teste'])); ?></td>
                        <td style="padding:8px;"><?php echo $r['pontuacao']; ?></td>
                        <td style="padding:8px;"><?php echo $r['nivel']; ?></td>
                    </tr>
                <?php } ?>
            </table>
        <?php } ?>
    </div>
</body>
</html>
