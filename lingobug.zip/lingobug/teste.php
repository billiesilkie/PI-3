<?php
include 'menu.php';

$mostrar_resultado = false;
$pontuacao = 0;
$nivel = "";

// Busca as questões
$questoes = $conexao->query("SELECT * FROM questoes ORDER BY id");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $respostas = $_POST['resposta'] ?? [];
    $pontuacao = 0;

    // Recalcula a pontuação
    $resultado_q = $conexao->query("SELECT * FROM questoes ORDER BY id");
    while ($q = $resultado_q->fetch_assoc()) {
        if (isset($respostas[$q['id']]) && $respostas[$q['id']] == $q['correta']) {
            $pontuacao += $q['peso'];
        }
    }

    // Define o nível
    if ($pontuacao <= 6) {
        $nivel = "Iniciante";
    } elseif ($pontuacao <= 13) {
        $nivel = "Intermediário";
    } else {
        $nivel = "Avançado";
    }

    // Salva o resultado no banco
    $sql = "INSERT INTO resultados (usuario_id, pontuacao, nivel) VALUES (?, ?, ?)";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("iis", $_SESSION['usuario_id'], $pontuacao, $nivel);
    $stmt->execute();

    $mostrar_resultado = true;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>LingoBug - Teste</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="conteudo">
        <h1>Teste de Inglês</h1>

        <?php if ($mostrar_resultado) { ?>
            <div class="resultado">
                <h2>Seu Resultado</h2>
                <p>Pontuação: <strong><?php echo $pontuacao; ?></strong></p>
                <p>Nível: <strong><?php echo $nivel; ?></strong></p>
                <br>
                <a href="teste.php" class="botao">Refazer Teste</a>
                <a href="perfil.php" class="botao-claro">Ver Histórico</a>
            </div>
        <?php } else { ?>
            <form method="POST" action="teste.php">
                <?php
                $numero = 1;
                while ($q = $questoes->fetch_assoc()) {
                    echo "<div class='questao'>";
                    echo "<p><strong>Questão $numero:</strong> " . htmlspecialchars($q['pergunta']) . "</p>";

                    foreach (['a', 'b', 'c', 'd'] as $letra) {
                        $texto = htmlspecialchars($q['alternativa_' . $letra]);
                        echo "<label class='alternativa'>";
                        echo "<input type='radio' name='resposta[" . $q['id'] . "]' value='$letra' required> ";
                        echo strtoupper($letra) . ") $texto";
                        echo "</label>";
                    }

                    echo "</div>";
                    $numero++;
                }
                ?>
                <button type="submit" class="botao">Finalizar Teste</button>
            </form>
        <?php } ?>
    </div>
</body>
</html>
